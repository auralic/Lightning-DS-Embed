'use strict';

/**
 * 1.0 beta
 * ohnet module 定义入口
 */

angular.module('ohnet', []);