angular.module('app')
  .directive('uiScrollTo', function($location, $anchorScroll, $log) {
    return {
      restrict: 'AC',
      link: function(scope, el, attr) {
        el.on('click', function(e) {
          $location.hash(attr.uiScrollTo);
          $anchorScroll();
        });
      }
    };
  });
